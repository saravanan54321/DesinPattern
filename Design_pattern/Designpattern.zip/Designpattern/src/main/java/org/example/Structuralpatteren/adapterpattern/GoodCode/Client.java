package org.example.Structuralpatteren.adapterpattern.GoodCode;


public class Client {

    public static void main(String[] args) {
        NotificationService ns = new AdapterPattern(new SendGrid()) ;
        ns.send();

    }}


